// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDJv-aIoK7q3XdxrzmknqZYMqQRhRb4uww",
  authDomain: "mern-47f6c.firebaseapp.com",
  projectId: "mern-47f6c",
  storageBucket: "mern-47f6c.appspot.com",
  messagingSenderId: "801151063022",
  appId: "1:801151063022:web:faf44e33c7e935ddeeb4ff"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);